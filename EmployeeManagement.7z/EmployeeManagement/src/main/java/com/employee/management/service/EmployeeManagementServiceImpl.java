package com.employee.management.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.management.Exception.EmployeeManagementException;
import com.employee.management.Model.EmployeeInputResponseTO;
import com.employee.management.dao.EmployeeManagementDao;
import com.employee.management.entity.Employee;

@Service
public class EmployeeManagementServiceImpl implements EmployeeManagementService {

	@Autowired
	EmployeeManagementDao  employeeManagementDao;
	

	@Override
	public EmployeeInputResponseTO addEmployee(Employee emp) throws EmployeeManagementException {
		return employeeManagementDao.saveEmployeeDetails(emp);
	}


	@Override
	public EmployeeInputResponseTO deleteEmployee(Employee emp) throws EmployeeManagementException {
		return employeeManagementDao.deleteEmployee(emp);
	}


	@Override
	public Employee getEmployee(int empId) {
		// TODO Auto-generated method stub
		return employeeManagementDao.getEmployee(empId);
	}

}
