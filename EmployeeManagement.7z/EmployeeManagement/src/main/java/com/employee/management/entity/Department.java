package com.employee.management.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Department")
public class Department {
	
	@Id
	@Column(name = "dept_id")
	private  int departmentid;
	
	@Column(name = "dept_name")
	private String departmentname;
	
	@Column(name = "dept_head")
	private String departmenthead;

	public Department(int departmentid, String departmentname, String departmenthead) {
		super();
		this.departmentid = departmentid;
		this.departmentname = departmentname;
		this.departmenthead = departmenthead;
	}

	public Department() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getDepartmentid() {
		return departmentid;
	}

	public void setDepartmentid(int departmentid) {
		this.departmentid = departmentid;
	}

	public String getDepartmentname() {
		return departmentname;
	}

	public void setDepartmentname(String departmentname) {
		this.departmentname = departmentname;
	}

	public String getDepartmenthead() {
		return departmenthead;
	}

	public void setDepartmenthead(String departmenthead) {
		this.departmenthead = departmenthead;
	}

	
}
