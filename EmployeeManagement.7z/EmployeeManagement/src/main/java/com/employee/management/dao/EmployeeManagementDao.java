package com.employee.management.dao;

import javax.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.employee.management.Exception.EmployeeManagementException;
import com.employee.management.Model.EmployeeInputResponseTO;
import com.employee.management.Repository.EmployeeManagementRepo;
import com.employee.management.entity.Employee;

@Repository
public class EmployeeManagementDao {
	
	@Autowired
	EmployeeManagementRepo employeeManagementJPARepo;
	
	
	public EmployeeInputResponseTO saveEmployeeDetails(Employee emp) {
		EmployeeInputResponseTO response = null;
		boolean flag = false;
		try {
			employeeManagementJPARepo.save(emp);
			flag=true;
			if(flag) {
				response = new EmployeeInputResponseTO(200, "Successfully added Employee Details");
			}
			else {
				throw new EmployeeManagementException(0, null);
			}
		}
		catch(EmployeeManagementException | IllegalArgumentException e) {
			response = new EmployeeInputResponseTO(((EmployeeManagementException) e).getStatuscode(), e.getMessage());
		}
		return response;
		
	}


	public EmployeeInputResponseTO deleteEmployee(Employee emp)  {
		EmployeeInputResponseTO response = null;
		boolean flag = false;
		try {
		employeeManagementJPARepo.delete(emp);
		flag = true;
		if(flag) {
			response = new EmployeeInputResponseTO(200, "Successfully added Employee Details");
		}
		else {
			throw new EmployeeManagementException(400,"deletion of employee failed");
		}
		}
		catch(EmployeeManagementException | IllegalArgumentException e) {
			response = new EmployeeInputResponseTO(((EmployeeManagementException) e).getStatuscode(), e.getMessage());
		}
		return response;
	}


	public Employee getEmployee(int empId) {
		Employee emp= null; 
		try {
		emp = employeeManagementJPARepo.getById(empId);
		}
		catch(EntityNotFoundException e) {
			System.out.println("Error while fecthing emp id" + e.getMessage());
		}
		return emp;
	}


}
