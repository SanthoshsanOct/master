package com.employee.management.Model;

public class EmployeeInputResponseTO {

	private int statuscode;
	private String message;

	public EmployeeInputResponseTO(int statuscode, String message) {
		super();
		this.statuscode = statuscode;
		this.message = message;
	}

	public int getStatuscode() {
		return statuscode;
	}

	public void setStatuscode(int statuscode) {
		this.statuscode = statuscode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}
