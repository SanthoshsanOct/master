package com.employee.management.service;


import com.employee.management.Exception.EmployeeManagementException;
import com.employee.management.Model.EmployeeInputResponseTO;
import com.employee.management.entity.Employee;


public interface EmployeeManagementService {
	public EmployeeInputResponseTO addEmployee(Employee emp) throws EmployeeManagementException;
	public EmployeeInputResponseTO deleteEmployee(Employee emp)throws EmployeeManagementException;
	public Employee getEmployee(int empId);
}
