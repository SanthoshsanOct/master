package com.employee.management.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import com.employee.management.entity.Employee;

@Component
public interface EmployeeManagementRepo extends JpaRepository<Employee, Integer>{

}
