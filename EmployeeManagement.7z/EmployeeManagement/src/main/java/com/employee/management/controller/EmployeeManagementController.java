package com.employee.management.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.employee.management.Exception.EmployeeManagementException;
import com.employee.management.Model.EmployeeInputResponseTO;
import com.employee.management.entity.Employee;
import com.employee.management.service.EmployeeManagementService;

@RestController
@RequestMapping("/api/emp")
public class EmployeeManagementController {
	
	@Autowired
	EmployeeManagementService employeeManagementService;
	
	@PostMapping(value = "/addemp" )
	public  EmployeeInputResponseTO addEmployee(@RequestBody Employee reqemp) throws EmployeeManagementException {
		return  employeeManagementService.addEmployee(reqemp);
	}
	
	
	@GetMapping(value = "/deleteemp/{id})")
	public Employee getEmp(@PathVariable int id) {
		return employeeManagementService.getEmployee(id);
		
	}
}
