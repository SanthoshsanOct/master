package com.employee.management.Exception;

public class EmployeeManagementException extends Exception{
	
	private int statuscode;
	private String msg;
	
	
	public EmployeeManagementException(int statuscode, String msg) {
		super();
		this.statuscode = statuscode;
		this.msg = msg;
	}


	public int getStatuscode() {
		return statuscode;
	}


	public void setStatuscode(int statuscode) {
		this.statuscode = statuscode;
	}


	public String getMsg() {
		return msg;
	}


	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	
}
