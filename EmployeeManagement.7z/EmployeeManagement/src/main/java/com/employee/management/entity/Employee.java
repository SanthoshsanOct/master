package com.employee.management.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Employee")
public class Employee {
	
	@Id
	@Column(name = "emp_id")
	private int employeeid; 
	
	@Column(name = "emp_name")
	private String name; 
	
	@Column(name = "dob")
	private String dob;
	
	@Column(name = "pan")
	private String pan;
	
	
	@Column(name = "address")
	private String address;
	
	@Column(name = "dept_id")
	private int departmentid;

	public Employee(int employeeid, String name, String dob, String pan, String address, int departmentid) {
		super();
		this.employeeid = employeeid;
		this.name = name;
		this.dob = dob;
		this.pan = pan;
		this.address = address;
		this.departmentid = departmentid;
	}

	public int getEmployeeid() {
		return employeeid;
	}

	public void setEmployeeid(int employeeid) {
		this.employeeid = employeeid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getDepartmentid() {
		return departmentid;
	}

	public void setDepartmentid(int departmentid) {
		this.departmentid = departmentid;
	}
	
	
	
}
